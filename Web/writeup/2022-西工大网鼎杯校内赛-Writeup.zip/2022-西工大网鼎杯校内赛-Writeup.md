# 2022-西工大网鼎杯校内赛-Writeup

## wbd_2020_九宫格

原题flag都没变。

## wdb_2018_1st_fakebook

原题。

## EasySQL

联合注入一下flag表的flag列就行了。

## wdb_2018_3rd_comein

原题

## codeception

网上找一个yii的对应版本的链子然后压缩一下生成的phar再phar反序列化就行了。