#!/bin/sh
python3 /opt/admin/main.py &
/opt/app/main