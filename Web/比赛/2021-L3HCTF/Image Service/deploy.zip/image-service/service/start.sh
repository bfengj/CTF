#!/bin/sh
/opt/app/main