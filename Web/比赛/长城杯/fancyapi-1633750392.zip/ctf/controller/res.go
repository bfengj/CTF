package controller

import (
	"encoding/json"
	"net/http"
)

func ok(w http.ResponseWriter, desc string) {
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]string{"msg": desc})
}

func fail(w http.ResponseWriter, desc string) {
	w.WriteHeader(http.StatusInternalServerError)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]string{"error": desc})
}
