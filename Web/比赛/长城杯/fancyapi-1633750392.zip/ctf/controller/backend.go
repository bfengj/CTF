package controller

import (
	db "ctf/database"
	"encoding/json"
	"fmt"
	"github.com/buger/jsonparser"
	"io/ioutil"
	"net/http"
)

type Language struct {
	Id  int32  `json:"id"`
	Name string `json:"name"`
	Votes int64 `json:"votes"`
}


func Index(w http.ResponseWriter, _ *http.Request) {
	ok(w, "Hello World!")
}

func List(w http.ResponseWriter, _ *http.Request) {

	rows, err := db.Sqlite.Query("SELECT * FROM languages;")
	if err != nil {
		fail(w, "Something wrong")
		fmt.Println(err.Error())
		return
	}
	defer rows.Close()

	res := make([]Language, 0)
	for rows.Next() {
		var pl Language
		_ = rows.Scan(&pl.Id, &pl.Name, &pl.Votes)
		res = append(res, pl)
	}
	err = json.NewEncoder(w).Encode(res)
}

func Search(w http.ResponseWriter, r *http.Request) {
	reqBody, _ := ioutil.ReadAll(r.Body)

	votes, err := jsonparser.GetInt(reqBody, "votes")
	if err != nil {
		fail(w, "Error reading votes")
		return
	}
	name, err := jsonparser.GetString(reqBody, "name")
	if err != nil {
		fail(w, "Error reading name")
		return
	}

	query := fmt.Sprintf("SELECT * FROM languages WHERE votes >= %d OR name LIKE '%s';", votes, name)
	rows, err := db.Sqlite.Query(query)
	if err != nil {
		fail(w, "Something wrong")
		fmt.Println(err.Error())
		return
	}
	res := make([]Language, 0)
	for rows.Next() {
		var pl Language
		_ = rows.Scan(&pl.Id, &pl.Name, &pl.Votes)
		res = append(res, pl)
	}
	err = json.NewEncoder(w).Encode(res)
}


func Flag(w http.ResponseWriter, r *http.Request ) {
	action:= r.URL.Query().Get("action")
	if action == "" {
		fail(w, "Error getting action")
		return
	}

	token:= r.URL.Query().Get("token")
	if token == "" {
		fail(w, "Error getting token")
		return
	}

	var secret string
	row := db.Sqlite.QueryRow("SELECT secret FROM token;")
	if err := row.Scan(&secret); err != nil {
		fail(w, "Error querying secret token")
		return
	}

	if action == "readFlag" && secret == token {
		data, err := ioutil.ReadFile("flag")
		if err != nil {
			fail(w, "Error reading flag")
			return
		}
		ok(w, fmt.Sprintf("Congrats this is your flag: %s", string(data)))
		return
	}
	ok(w, "Wrong token")
}