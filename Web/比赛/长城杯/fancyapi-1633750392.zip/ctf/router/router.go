package router

import (
	. "ctf/controller"
	"github.com/gorilla/mux"
)

func Init() *mux.Router {

	router := mux.NewRouter()

	router.HandleFunc("/", Index).Methods("GET")
	router.HandleFunc("/flag", Flag).Methods("GET")
	router.HandleFunc("/api/list", List).Methods("POST")
	router.HandleFunc("/api/search", Search).Methods("POST")

	return router
}
