package database

import (
	"database/sql"
	_ "github.com/mattn/go-sqlite3"
	"log"
)

var Sqlite *sql.DB

func init() {
	var err error
	Sqlite, err = sql.Open("sqlite3", "./db.sqlite3")
	if err != nil {
		log.Fatal(err.Error())
	}
	err = Sqlite.Ping()
	if err != nil {
		log.Fatal(err.Error())
	}

}
