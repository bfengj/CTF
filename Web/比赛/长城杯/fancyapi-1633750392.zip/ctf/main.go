package main

import (
	. "ctf/router"
	"log"
	"net/http"
)

func main() {
	http.Handle("/", Init())
	err := http.ListenAndServe("127.0.0.1:8000", nil)
	if err != nil {
		log.Fatal(err.Error())
	}
}
