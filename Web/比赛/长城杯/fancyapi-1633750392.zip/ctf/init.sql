CREATE TABLE languages  (
    id INTEGER AUTO INCREMENT ,
    name CHAR(20),
    votes INTEGER
);

INSERT INTO languages(id, name, votes) values (1, 'java', 3400);
INSERT INTO languages(id, name, votes) values (2, 'typescript', 1911);
INSERT INTO languages(id, name, votes) values (3, 'php', 4377);
INSERT INTO languages(id, name, votes) values (4, 'golang', 2523);
INSERT INTO languages(id, name, votes) values (5, 'python', 5621);
INSERT INTO languages(id, name, votes) values (6, 'rust', 672);


create table token (secret TEXT);
insert into token values ('xxx');