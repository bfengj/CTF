from flask import Flask, request, render_template, jsonify
from urllib.parse import unquote
import requests

app = Flask(__name__)

server = '127.0.0.1:8000'


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/list", methods=["POST"])
def listAll():
    r = requests.post(f"http://{server}/api/list")
    return jsonify(r.json())


@app.route("/search", methods=["GET", "POST"])
def search():
    if request.method == "GET":
        return render_template("search.html")
    else:
        data = request.json
        if data['name']:
            if not isinstance(data['name'], str) or not data['name'].isalnum():
                return jsonify({"error": "Bad word detected"})
        if data['votes']:
            if not isinstance(data['votes'], int):
                return jsonify({"error": "Bad word detected"})
        r = requests.post(f"http://{server}/api/search", data=request.data)
        return jsonify(r.json())


@app.route("/healthcheck", methods=["GET"])
def healthCheck():
    getPath = ["", "flag"]
    postPath = ["api/list", "api/search"]
    try:
        for path in getPath:
            requests.get(f"http://{server}/{path}")
        for path in postPath:
            requests.post(f"http://{server}/{path}")
    except:
        return "Down"
    return "OK"


@app.route("/<path:path>", methods=["GET"])
def handle(path):
    if 'flag' in unquote(path):
        action = request.args.get('action')
        token = request.args.get('token')
        print(action)
        if action == "readFlag":
            return jsonify({"error": "Sorry, readFlag is not permitted"})
        r = requests.get(f"http://{server}/{path}", params={
            "action": action,
            "token": token
        })
    else:
        r = requests.get(f"http://{server}/{path}")
    return jsonify(r.text)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
