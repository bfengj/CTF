create database www;
use www;
create table user_data(
    username varchar (256),
    password varchar (256)
);
