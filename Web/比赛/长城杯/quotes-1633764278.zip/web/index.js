const express = require('express');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const createError = require('http-errors');
const utils = require('./utils');
const router = require('./router/index');
const cons = require('consolidate');

const app = express();

app.engine('dust', cons.dust);
app.set('view engine', 'dust')
app.set('views', __dirname + '/views');
app.use("/static", express.static("static"));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(logger('dev'));

app.use('/', utils.waf, router);

app.use((_req, _res, next) => {
    next(createError(404));
})

app.use((err, _req, res, _) => {
    res.locals.message = err.message;
    res.locals.status = err.status;

    res.status(err.status || 500);
    res.render('error');
});


app.listen(3000, () => {
    console.log('Listening at port 3000');
});