
const banWords = [
    /constructor/i,
    /prototype/i,
    /__proto__/i,
    /flag/i,
];

const set = (object, path, val, obj) => {
    return !/^(__proto__|constructor|prototype).*$/.test(path) && ((path = path.split ? path.split('.') : path.slice(0)).slice(0, -1).reduce( (obj, p) => {
        return obj[p] = obj[p] || {};
    }, obj = object)[path.pop()] = val), object;
}


const check = (input) => {
    const percentEncoded = /%[a-fA-F0-9]{2}/i.test(input);
    if (percentEncoded) {
        return check(decodeURIComponent(input));
    }

    for (const bad of banWords) {
        if (bad.test(input)) {
            return true;
        }
    }
    return false;
}

const isBad = (req) => {
    const toCheck = ['url', 'body', 'cookies'];
    for (const key of toCheck) {
        const value = req[key];
        if (!value) {
            continue;
        }
        if (typeof (value) === "string" && check(value)) {
            return key;
        }
        if (typeof (value) === "object" && check(JSON.stringify(value))) {
            return key;
        }
    }
    return null;
}


async function waf(req, res, next) {
    let blockReason;
    try {
        blockReason = isBad(req);
        if (blockReason !== null) {
            return res.status(403).render('error', {
                status: 403,
                message: `Waf protection: Bad words detected in ${blockReason.toUpperCase()}`
            })
        }
    } catch (err) {
        console.log(err);
    }
    if (blockReason == null) {
        next();
    }
};

module.exports = {
    set,
    waf
}