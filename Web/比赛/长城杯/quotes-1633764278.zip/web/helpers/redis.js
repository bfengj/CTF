const Promise = require("bluebird");
const redisClient = Promise.promisifyAll(
    require('redis').
        createClient(
            6379, '127.0.0.1'
        )
);

const SUFFIX = '_quotes'

const keyName = (keyName) => keyName + SUFFIX;

const setQuote = async (key, data) => {
    try {
        await redisClient.setAsync(keyName(key), data);
    } catch (err) {
        console.log(err);
    }
}

const getQuote = async (key) => {
    let res = null;
    try {
        res = await redisClient.getAsync(keyName(key));
    } catch (err) {
        console.log(err);
    }
    return JSON.parse(res);
}

module.exports = {
    setQuote,
    getQuote
}