const express = require('express');
const router = express.Router();
const utils = require('../utils');
const createError = require('http-errors');
const { v4: uuidv4 } = require('uuid');
const { getQuote, setQuote } = require('../helpers/redis');

router.get("/", (req, res) => {
    let userId = req.cookies?.userId;
    if (!userId) {
        userId = uuidv4();
        res.cookie('userId', userId, { maxage: 10800, httponly: true });
    }
    return res.redirect("/quotes")
});


router.get("/quotes", async (req, res) => {
    let userId = req.cookies?.userId;
    if (userId) {
        const infos = await getQuote(userId);
        let quotes = [];
        if (Array.isArray(infos) && infos.length) {
            infos.forEach((info, id) => {
                let quote = { id: id + 1 };
                Object.keys(info).forEach((key) => {
                    utils.set(quote, key, info[key]);
                });
                quotes.push(quote);
            });
        }
        res.render("index", { quotes });
    } else {
        res.redirect("/");
    }
});

router.post("/quotes/add", async (req, res, next) => {
    let userId = req.cookies?.userId;
    if (userId) {
        let { author, quote } = req.body;
        if (!quote || !author) {
            return res.redirect("/quotes");
        }
        let quotes = [];
        const info = await getQuote(userId);
        if (info !== null) {
            quotes = quotes.concat(info);
        }
        quotes.push(req.body);
        try {
            await setQuote(userId, JSON.stringify(quotes));
        } catch (err) {
            console.log(err);
            next(createError(500));
        }
        return res.redirect("/quotes");

    } else {
        res.redirect("/");
    }
});

router.get("/quotes/delete/:id", async (req, res, next) => {
    let userId = req.cookies?.userId;
    if (userId) {
        let id = req.params.id;
        let quotes = [];
        const info = await getQuote(userId);
        if (info == null) {
            return res.redirect("/");
        }
        quotes = quotes.concat(info);
        quotes.splice(id - 1, 1);
        try {
            await setQuote(userId, JSON.stringify(quotes));
        } catch (err) {
            console.log(err);
            next(createError(500));
        }
        return res.redirect("/quotes");

    } else {
        res.redirect("/");
    }
});

router.get('/healthcheck', (_, res) => {
    quotes = [{
        author: 'test',
        quote: 'test'
    }]
    res.render('index', { quotes });
});


module.exports = router;