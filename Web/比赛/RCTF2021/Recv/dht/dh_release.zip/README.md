# distributed hash
no description given

## release file
`chal`

# private
all sections below are not for players

## answer
flag{c64459bb76582a53}

## solution
`solve.py`
can be optimized but it works (python solve.py  199.75s user 0.03s system 99% cpu 3:19.88 total)

## comments
Due to uncertainty in execution time of threads, this binary only accept flag with a low probability even with correct input. This is intended.

I do not strip the binary since it can be annoying to reverse rust. But this is an alternative if you need a harder challenge.
