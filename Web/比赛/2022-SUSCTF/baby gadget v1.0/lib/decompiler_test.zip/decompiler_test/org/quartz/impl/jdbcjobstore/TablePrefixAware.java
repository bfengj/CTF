package org.quartz.impl.jdbcjobstore;

public interface TablePrefixAware {
   void setTablePrefix(String var1);

   void setSchedName(String var1);
}
