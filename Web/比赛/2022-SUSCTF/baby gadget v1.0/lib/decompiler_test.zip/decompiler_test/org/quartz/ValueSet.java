package org.quartz;

class ValueSet {
   public int value;
   public int pos;
}
