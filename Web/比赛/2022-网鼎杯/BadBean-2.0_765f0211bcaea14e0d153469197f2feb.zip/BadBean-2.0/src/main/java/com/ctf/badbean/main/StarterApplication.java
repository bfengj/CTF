package com.ctf.badbean.main;

import org.springframework.boot.autoconfigure.*;
import org.springframework.boot.*;

@SpringBootApplication
public class StarterApplication
{
    public static void main(final String[] args) {
        SpringApplication.run(StarterApplication.class, args);
    }
}