<?php
//000000000000
 exit();?>
D:\learn\code\ThinkCMF-5.1/data/runtime\cache\c3\0b008a754ac7f1eeef085057ee3106.php