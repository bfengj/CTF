<?php	return array (
  'secretUriHaha$' => 'admin/Index/index',
);

