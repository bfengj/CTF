<?php
return [
    // 指令名 =》完整的类名
    'plugin:hello' => 'plugins\demo\command\Hello'
];
