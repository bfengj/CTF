<?php
return [
    // 指令名 =》完整的类名
    'demo:hello' => 'app\demo\command\Hello'
];
