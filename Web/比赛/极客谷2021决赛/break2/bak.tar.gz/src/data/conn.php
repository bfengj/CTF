<?php
$db_host = "10.10.20.166";
$db_user = "root";
$db_pwd = "Miaomiaomiao";
$db_name = "wyx";
$db_port = "3306";
$mysql_tag = "tgs_";
?>
