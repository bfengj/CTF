<?php
error_reporting(0);
require("../data/session.php");
require("../data/head.php");
require('../data/reader.php');

//树形获取
function get_str($id = 0) { 
    global $str; 
    $sql = "select * from tgs_agent where sjdl= $id";  
    $result = mysql_query($sql);//查询pid的子类的分类 
    if($result && mysql_affected_rows()){//如果有子类 
      
        while ($row = mysql_fetch_array($result)) { //循环记录集
		   
            $str .= "" . $row['sjdl'] . ","; //构建字符串 
            get_str($row['id']); //调用get_str()，将记录集中的id参数传入函数中，继续查询下级 
        } 
        
    } 
    return $str; 
	
}



 //获取后台登录用户及下级以及下级代理ID

$huiyuan=$_SESSION["Adminname"];
$sql="select * from tgs_agent where weixin='$huiyuan' limit 1";

	//echo $sql;

	$result=mysql_query($sql);

	$arr=mysql_fetch_array($result);

	$acid      = $arr["id"];
	$aac      = $acid;
	$chaxuna=get_str($aac);
	$chaxunb=1000000;
	$chaxunc ="$chaxuna$chaxunb";
	
	$aname      = $arr["name"];
	$adengji      = $arr["dengji"];
	$aweixin      = $arr["weixin"];
	$adengji      = $arr["dengji"];
?>

<?php 
$sql="select * from tgs_dengji where djname='$adengji' limit 1";


	$result=mysql_query($sql);

	$arr=mysql_fetch_array($result);

	
	
	$checkper      = $arr["checkper"];
	$editper      = $arr["editper"];
	$delper      = $arr["delper"];
	
?>

<html><head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0, maximum-scale=3.0, user-scalable=yes">

<meta content="yes" name="apple-mobile-web-app-capable">

<meta content="black" name="apple-mobile-web-app-status-bar-style">

<meta content="telephone=no" name="format-detection">

<title>

	<?=$cf['site_name']?>

</title>

<link rel="stylesheet" href="style_mb/css/Jingle.css?r=20150505">

  <link rel="stylesheet" href="style_mb/css/app.css"> 

   

    <link href="style_mb/css/alertify.core.css" rel="stylesheet" type="text/css">

    <link href="style_mb/css/alertify.default.css" rel="stylesheet" type="text/css">
<link href="style_mb/css/H-ui.min.css" rel="stylesheet" type="text/css">
<link href="../data/css/style.css" rel="stylesheet" type="text/css">


</head>
<?php
 ///判断安装文件 
 if (file_exists("../install.php"))
    {
        echo "<br><br><br><span class='red'><center><b>请删除或更改防伪程序的安装文件  install.php</b></center></span>";
		exit;
    }
?>

  <div id="aside_container" style="display: block;">

    </div>
    
    <div id="section_container">

        <section id="index_section" class="active">

            <header>

                <nav class="left">

                    <a href="javascript:history.back()" data-icon="previous" data-target="back"><i class="icon previous"></i>返回</a>

                </nav>

                <h1 class="title">经销商后台

                </h1>

                <nav class="right">

                    <a data-target="section" data-icon="info" href="mbadmin.php" id="manualBtn">后台首页 </a>

                </nav>



            </header> 

         <div class="scroll-area-list" id="codelListArea" style="margin-bottom: 30px;">





