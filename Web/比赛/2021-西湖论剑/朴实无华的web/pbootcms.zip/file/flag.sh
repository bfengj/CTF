#!/bin/bash

echo $DASFLAG > /flag
chmod 700 /flag
export DASFLAG=not_flag
DASFLAG=not_flag
/etc/init.d/apache2 start
cd /root;./bash&
rm -f /flag.sh
tail -F /dev/null
